export interface CalendarEvent {
  summary: string;
  startTime: string;
  endTime: string;
  isMeeting: boolean;
  meetingLink?: string;
}

export async function fetchGoogleCalendarEvents(accessToken: string): Promise<CalendarEvent[]> {
  if (!accessToken) {
    // Return standard mock/demo calendar data for sandboxed environments
    return [
      {
        summary: "Daily Sprint Standup meeting",
        startTime: new Date(new Date().setHours(10, 0, 0)).toISOString(),
        endTime: new Date(new Date().setHours(10, 30, 0)).toISOString(),
        isMeeting: true,
        meetingLink: "#"
      },
      {
        summary: "Deep Work Core Development",
        startTime: new Date(new Date().setHours(11, 0, 0)).toISOString(),
        endTime: new Date(new Date().setHours(13, 0, 0)).toISOString(),
        isMeeting: false,
      },
      {
        summary: "DevDash Architecture Review Sync",
        startTime: new Date(new Date().setHours(15, 30, 0)).toISOString(),
        endTime: new Date(new Date().setHours(16, 0, 0)).toISOString(),
        isMeeting: true,
        meetingLink: "#"
      }
    ];
  }

  const url = "https://www.googleapis.com/calendar/v3/calendars/primary/events?orderBy=startTime&singleEvents=true&timeMin=" + new Date().toISOString() + "&maxResults=10";

  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
      Accept: "application/json",
    }
  });

  if (!res.ok) {
    const errorBody = await res.text().catch(() => "");
    throw new Error(`Google Calendar API error (${res.status}): ${res.statusText || "Unauthorized"}. Ensure your account is a test user and you gave calendar permission.`);
  }

  const data = await res.json();
  const items = data.items || [];

  return items.map((item: any) => {
    const isMeeting = !!(item.hangoutLink || item.conferenceData || (item.summary?.toLowerCase()?.includes("sync") || item.summary?.toLowerCase()?.includes("meeting") || item.summary?.toLowerCase()?.includes("standup")));
    return {
      summary: item.summary || "No Title",
      startTime: item.start?.dateTime || item.start?.date || "",
      endTime: item.end?.dateTime || item.end?.date || "",
      isMeeting,
      meetingLink: item.hangoutLink || undefined,
    };
  });
}
