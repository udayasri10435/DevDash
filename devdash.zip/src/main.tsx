import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Silence benign React 19 defaultProps warnings/errors triggered by legacy Recharts internals
const originalConsoleError = console.error;
console.error = (...args: any[]) => {
  if (typeof args[0] === "string" && (args[0].includes("defaultProps") || args[0].includes("Support for defaultProps"))) {
    return;
  }
  originalConsoleError(...args);
};

const originalConsoleWarn = console.warn;
console.warn = (...args: any[]) => {
  if (typeof args[0] === "string" && (args[0].includes("defaultProps") || args[0].includes("Support for defaultProps"))) {
    return;
  }
  originalConsoleWarn(...args);
};

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
