import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, initializeAuth, inMemoryPersistence } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import firebaseConfig from "../firebase-applet-config.json";

// Ensure we have a valid configuration object or fallback to prevent startup crash
const safeConfig = {
  apiKey: firebaseConfig?.apiKey || "",
  authDomain: firebaseConfig?.authDomain || "",
  projectId: firebaseConfig?.projectId || "",
  storageBucket: firebaseConfig?.storageBucket || "",
  messagingSenderId: firebaseConfig?.messagingSenderId || "",
  appId: firebaseConfig?.appId || ""
};

// Initialize Firebase safely
const app = getApps().length === 0 ? initializeApp(safeConfig) : getApp();

// Initialize Firebase Authentication with storage/iframe sandboxing safety gates
let tempAuth: any;
try {
  tempAuth = getAuth(app);
} catch (error) {
  console.warn("Standard Firebase Auth initialization failed. Attempting secure in-memory sandbox persistence fallback:", error);
  try {
    tempAuth = initializeAuth(app, {
      persistence: inMemoryPersistence,
    });
  } catch (initError) {
    console.error("Critical: Could not initialize Firebase Auth in sandboxed iframe.", initError);
    // Secure stub fallback so the import doesn't fail the initial script load
    tempAuth = {
      onAuthStateChanged: (callback: any) => {
        const unsubscribe = () => {};
        setTimeout(() => callback(null), 0);
        return unsubscribe;
      },
      signOut: async () => {},
    } as any;
  }
}

export const auth = tempAuth;
export const googleProvider = new GoogleAuthProvider();

// Initialize Firestore safely with iframe storage fallback
let tempDb: any;
try {
  tempDb = firebaseConfig?.firestoreDatabaseId
    ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
    : getFirestore(app);
} catch (error) {
  console.error("Failed to initialize Firestore database. Falling back to safe mock database.", error);
  tempDb = {} as any;
}
export const db = tempDb;

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid || null,
      email: auth.currentUser?.email || null,
      emailVerified: auth.currentUser?.emailVerified || null,
      isAnonymous: auth.currentUser?.isAnonymous || null,
      tenantId: auth.currentUser?.tenantId || null,
      providerInfo: auth.currentUser?.providerData?.map((provider: any) => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}


