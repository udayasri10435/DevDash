/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { onAuthStateChanged, signOut, User as FirebaseUser, getRedirectResult, GoogleAuthProvider } from "firebase/auth";
import { collection, query, orderBy, onSnapshot, setDoc, doc, deleteDoc, getDoc } from "firebase/firestore";
import { auth, db, handleFirestoreError, OperationType } from "./firebase";
import { UserProfile, WorkSession, IntegrationStats } from "./types";
import DeveloperAuth from "./components/DeveloperAuth";
import PomodoroTimer from "./components/PomodoroTimer";
import DeepWorkTracker from "./components/DeepWorkTracker";
import IntegrationsPanel from "./components/IntegrationsPanel";
import ProductivityCharts from "./components/ProductivityCharts";
import ErrorBoundary from "./components/ErrorBoundary";
import { GitHubStats } from "./services/api/github";
import { JiraIssueStats } from "./services/api/jira";
import { CalendarEvent } from "./services/api/calendar";
import {
  LogOut,
  LogIn,
  Sparkles,
  Github,
  KanbanSquare,
  Calendar as CalendarIcon,
  HelpCircle,
  TrendingUp,
  Brain,
  Info,
  Download
} from "lucide-react";

export default function App() {
  // Authentication states
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [isSandbox, setIsSandbox] = useState(true);
  const [sandboxId, setSandboxId] = useState("sandbox_developer");
  const [loading, setLoading] = useState(true);

  // User Profile configuration
  const [profile, setProfile] = useState<UserProfile | null>({
    userId: "sandbox_developer",
    displayName: "Internal Sandbox Dev",
    email: "sandbox@aistudio.internal",
    deepWorkGoal: 5.0,
    pomodoroLength: 25,
  });
  // Work and Rest sessions today
  const [sessions, setSessions] = useState<WorkSession[]>([
    {
      sessionId: "mock-1",
      userId: "sandbox_developer",
      type: "deep_work",
      startTime: new Date(Date.now() - 3.55 * 3600 * 1000).toISOString(),
      duration: 2.5 * 3600,
      category: "Code Editing",
      notes: "Optimized express routes, initialized bundle scripts",
    },
    {
      sessionId: "mock-2",
      userId: "sandbox_developer",
      type: "pomodoro",
      startTime: new Date(Date.now() - 12 * 3600 * 1000).toISOString(),
      duration: 25 * 60,
      category: "UI Refinement",
      notes: "Design beautiful burnout gauge with SVG canvas lines",
    },
    {
      sessionId: "mock-3",
      userId: "sandbox_developer",
      type: "break",
      startTime: new Date(Date.now() - 11.5 * 3600 * 1000).toISOString(),
      duration: 5 * 60,
      category: "Recreation",
      notes: "Walked around for core stretch and fetched high-quality water",
    },
  ]);

  // Subscribed live metrics
  const [gitStats, setGitStats] = useState<GitHubStats | null>(null);
  const [jiraStats, setJiraStats] = useState<JiraIssueStats | null>(null);
  const [calendarEvents, setCalendarEvents] = useState<CalendarEvent[]>([]);

  // Integration summaries
  const [integrationStats, setIntegrationStats] = useState<IntegrationStats>({
    github: { connected: false, username: "", commitsCount: 0, openPrsCount: 0, mergedPrsCount: 0, prsReviewSpeed: 2.1 },
    jira: { connected: false, domain: "", todoCount: 0, inProgressCount: 0, doneCount: 0, sprintVelocity: 0 },
    googleCalendar: { connected: false, eventsTodayCount: 0, meetingsDuration: 0 },
  });

  // Capture Google Access Token after redirection
  useEffect(() => {
    getRedirectResult(auth)
      .then((result) => {
        if (result) {
          const credential = GoogleAuthProvider.credentialFromResult(result);
          const token = credential?.accessToken;
          if (token) {
            sessionStorage.setItem("google_access_token", token);
            window.dispatchEvent(new Event("google_token_updated"));
          }
        }
      })
      .catch((err) => {
        console.error("Error retrieving redirect result for Google Access Token:", err);
      });
  }, []);

  // Track state loading
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setLoading(true);
      if (currentUser) {
        setUser(currentUser);
        setIsSandbox(false);
        // Load Profile or create default
        try {
          const userDocRef = doc(db, "users", currentUser.uid);
          let profileDoc;
          try {
            profileDoc = await getDoc(userDocRef);
          } catch (err) {
            handleFirestoreError(err, OperationType.GET, `users/${currentUser.uid}`);
            throw err;
          }

          if (profileDoc && profileDoc.exists()) {
            setProfile(profileDoc.data() as UserProfile);
          } else {
            const defaultProfile: UserProfile = {
              userId: currentUser.uid,
              displayName: currentUser.displayName || "Studio Developer",
              email: currentUser.email || "",
              deepWorkGoal: 4.5,
              pomodoroLength: 25,
            };
            try {
              await setDoc(userDocRef, defaultProfile);
            } catch (err) {
              handleFirestoreError(err, OperationType.CREATE, `users/${currentUser.uid}`);
              throw err;
            }
            setProfile(defaultProfile);
          }
        } catch (error) {
          console.warn("Error getting user profile, creating in-memory default profile.", error);
          setProfile({
            userId: currentUser.uid,
            displayName: currentUser.displayName || "Secure Developer",
            email: currentUser.email || "",
            deepWorkGoal: 4.0,
            pomodoroLength: 25,
          });
        }
      } else {
        setUser(null);
        if (!isSandbox) {
          setProfile(null);
          setSessions([]);
        }
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [isSandbox]);

  // Firestore Snapshot sync for focused session logs
  useEffect(() => {
    if (!user) return;
    const currentId = user.uid;

    let unsubscribe = () => {};
    try {
      const q = query(
        collection(db, "users", currentId, "sessions"),
        orderBy("startTime", "desc")
      );

      unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          const loadedSessions: WorkSession[] = [];
          snapshot.forEach((doc) => {
            loadedSessions.push(doc.data() as WorkSession);
          });
          setSessions(loadedSessions);
        },
        (error) => {
          console.warn("Could not sync Firestore sessions in real-time. Operating with secure local memory flow.");
          handleFirestoreError(error, OperationType.LIST, `users/${currentId}/sessions`);
        }
      );
    } catch (e) {
      console.warn("Firestore snapshot sync setup failed. Operating with secure local memory flow:", e);
    }

    return () => unsubscribe();
  }, [user, isSandbox, sandboxId]);

  // Trigger default profile and mock sessions when Sandbox Mode is entered
  const handleSandboxLogin = () => {
    setIsSandbox(true);
    setProfile({
      userId: sandboxId,
      displayName: "Internal Sandbox Dev",
      email: "sandbox@aistudio.internal",
      deepWorkGoal: 5.0,
      pomodoroLength: 25,
    });
    // Generate simulated sessions for standard analytics demonstration
    const dummyLogs: WorkSession[] = [
      {
        sessionId: "mock-1",
        userId: sandboxId,
        type: "deep_work",
        startTime: new Date(Date.now() - 3.55 * 3600 * 1000).toISOString(),
        duration: 2.5 * 3600,
        category: "Code Editing",
        notes: "Optimized express routes, initialized bundle scripts",
      },
      {
        sessionId: "mock-2",
        userId: sandboxId,
        type: "pomodoro",
        startTime: new Date(Date.now() - 12 * 3600 * 1000).toISOString(),
        duration: 25 * 60,
        category: "UI Refinement",
        notes: "Design beautiful burnout gauge with SVG canvas lines",
      },
      {
        sessionId: "mock-3",
        userId: sandboxId,
        type: "break",
        startTime: new Date(Date.now() - 11.5 * 3600 * 1000).toISOString(),
        duration: 5 * 60,
        category: "Recreation",
        notes: "Walked around for core stretch and fetched high-quality water",
      },
    ];
    setSessions(dummyLogs);
  };

  const handleUpdateProfile = async (profileUpdates: Partial<UserProfile>) => {
    const currentId = user ? user.uid : sandboxId;
    if (!profile) return;

    const updatedProfile = { ...profile, ...profileUpdates };
    setProfile(updatedProfile);

    if (user) {
      try {
        await setDoc(doc(db, "users", currentId), updatedProfile);
      } catch (err) {
        console.error("Firestore sync error updates failed:", err);
        handleFirestoreError(err, OperationType.UPDATE, `users/${currentId}`);
      }
    }
  };

  const handleSaveSession = async (sessionData: Omit<WorkSession, "sessionId" | "userId" | "startTime">) => {
    const currentId = user ? user.uid : sandboxId;
    const randomId = "sess_" + Math.random().toString(36).substring(2, 11);
    const dateNowStr = new Date().toISOString();

    const newSessionItem: WorkSession = {
      ...sessionData,
      sessionId: randomId,
      userId: currentId,
      startTime: dateNowStr,
    };

    // Update local state instantly
    setSessions((prev) => [newSessionItem, ...prev]);

    if (user) {
      try {
        await setDoc(doc(db, "users", currentId, "sessions", randomId), newSessionItem);
      } catch (err) {
        console.error("Failed persisting session to Firestore cloud database:", err);
        handleFirestoreError(err, OperationType.CREATE, `users/${currentId}/sessions/${randomId}`);
      }
    }
  };

  const handleDeleteSession = async (sessionId: string) => {
    const currentId = user ? user.uid : sandboxId;
    setSessions((prev) => prev.filter((s) => s.sessionId !== sessionId));

    if (user) {
      try {
        await deleteDoc(doc(db, "users", currentId, "sessions", sessionId));
      } catch (err) {
        console.error("Failed deleting session node from Firestore:", err);
        handleFirestoreError(err, OperationType.DELETE, `users/${currentId}/sessions/${sessionId}`);
      }
    }
  };

  const handleSignOut = async () => {
    if (isSandbox) {
      setIsSandbox(false);
      setProfile(null);
      setSessions([]);
    } else {
      await signOut(auth);
    }
  };

  // Callback sync handlers
  const onGitHubSync = (stats: GitHubStats) => {
    setGitStats(stats);
    setIntegrationStats((prev) => ({
      ...prev,
      github: {
        connected: true,
        username: stats.username,
        commitsCount: stats.commitsCount,
        openPrsCount: stats.openPrsCount,
        mergedPrsCount: stats.mergedPrsCount,
        prsReviewSpeed: stats.prsReviewSpeed,
      },
    }));
  };

  const onJiraSync = (stats: JiraIssueStats) => {
    setJiraStats(stats);
    setIntegrationStats((prev) => ({
      ...prev,
      jira: {
        connected: true,
        domain: profile?.jiraDomain || "Atlassian Cloud",
        todoCount: stats.todoCount,
        inProgressCount: stats.inProgressCount,
        doneCount: stats.doneCount,
        sprintVelocity: stats.sprintVelocity,
      },
    }));
  };

  const onCalendarSync = (events: CalendarEvent[]) => {
    setCalendarEvents(events);
    const meetings = events.filter((e) => e.isMeeting);
    // sum duration of meetings
    const duration = meetings.reduce((acc, e) => {
      const diffMs = new Date(e.endTime).getTime() - new Date(e.startTime).getTime();
      return acc + diffMs / (60 * 1000);
    }, 0);

    setIntegrationStats((prev) => ({
      ...prev,
      googleCalendar: {
        connected: true,
        eventsTodayCount: events.length,
        meetingsDuration: Math.round(duration),
      },
    }));
  };

  const handleExportCalendarCSV = () => {
    if (calendarEvents.length === 0) return;

    const headers = ["Event Summary", "Start Time", "End Time", "Is Meeting?", "Meeting Link"];
    const rows = calendarEvents.map((evt) => {
      const summary = `"${(evt.summary || "").replace(/"/g, '""')}"`;
      const start = `"${evt.startTime || ""}"`;
      const end = `"${evt.endTime || ""}"`;
      const isMeeting = evt.isMeeting ? "Yes" : "No";
      const meetingLink = `"${(evt.meetingLink || "").replace(/"/g, '""')}"`;
      return [summary, start, end, isMeeting, meetingLink];
    });

    const csvContent = [headers.join(","), ...rows.map((row) => row.join(","))].join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `calendar_events_export_${new Date().toISOString().split("T")[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0c0d0f] flex flex-col items-center justify-center text-slate-400 font-mono gap-4">
        <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
        <span>Accessing developer security nodes...</span>
      </div>
    );
  }

  if (!user && !isSandbox) {
    return <DeveloperAuth onSandboxLogin={handleSandboxLogin} />;
  }

  return (
    <div className="min-h-screen bg-[#0c0d0f] text-slate-100 font-sans pb-16">
      
      {/* Glow ambient panels */}
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-indigo-500/5 rounded-full filter blur-[120px] pointer-events-none select-none"></div>
      <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-indigo-500/5 rounded-full filter blur-[120px] pointer-events-none select-none"></div>

      {/* Main Core Navigation Bar */}
      <nav id="header_navbar" className="border-b border-slate-800 bg-[#111216]/80 sticky top-0 z-30 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-tr from-indigo-600 to-indigo-500 p-1.5 rounded-xl text-white shadow-xl">
              <Brain className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <span className="font-extrabold tracking-tight text-white font-sans text-lg flex items-center gap-1.5">
                DevDash
                <span className="text-[10px] font-mono border border-slate-700 rounded px-1 text-slate-400 py-0.5 bg-slate-850">
                  {isSandbox ? "SANDBOX" : "LIVE CLOUD"}
                </span>
              </span>
              <p className="text-[9px] text-slate-500 font-mono tracking-wider uppercase">FATIGUE MITIGATION RAIL</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden sm:flex flex-col text-right font-sans">
              <span className="text-xs font-semibold text-slate-200">{profile?.displayName || "Developer Node"}</span>
              <span className="text-[10px] text-slate-400 font-mono italic">{profile?.email || "offline"}</span>
            </div>
            
            {isSandbox ? (
              <button
                onClick={handleSignOut}
                className="p-2 bg-indigo-950/45 hover:bg-indigo-900/60 border border-indigo-500/25 hover:border-indigo-500/40 rounded-xl text-indigo-400 hover:text-indigo-300 transition duration-150 flex items-center gap-2 text-xs font-mono"
                title="Exit local sandbox and open real-time Cloud authentication"
              >
                <LogIn className="w-4 h-4" />
                <span>Go Live / Sign In</span>
              </button>
            ) : (
              <button
                onClick={handleSignOut}
                className="p-2 bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl text-slate-400 hover:text-rose-400 transition duration-150 flex items-center gap-2 text-xs font-mono"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden md:inline">Sign Out</span>
              </button>
            )}
          </div>
        </div>
      </nav>

      {/* Core Responsive Workspace Grid Layout */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Side: Integrations status dashboard details */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-[#111216]/50 border border-slate-800 rounded-2xl p-5">
            <h3 className="text-xs uppercase tracking-widest font-mono font-bold text-slate-400 mb-4 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-400 animate-spin" /> Systems Connection Console
            </h3>
            <IntegrationsPanel
              userProfile={profile}
              onUpdateProfile={handleUpdateProfile}
              onGitHubSync={onGitHubSync}
              onJiraSync={onJiraSync}
              onCalendarSync={onCalendarSync}
            />
          </div>

          {/* Connected statistics summaries */}
          <div className="bg-[#111216] border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
            <h3 className="text-xs uppercase tracking-widest font-mono font-bold text-slate-400">Integrated telemetry</h3>
            
            {/* Github metrics */}
            <div className="flex items-center justify-between p-3 bg-[#0c0d0f]/40 border border-slate-800 rounded-xl text-xs font-mono">
              <div className="flex items-center gap-2">
                <Github className="w-4 h-4 text-indigo-400" />
                <span className="font-sans text-slate-300">GitHub Commits</span>
              </div>
              <span className="text-indigo-400 font-bold">{integrationStats.github.connected ? integrationStats.github.commitsCount : "—"}</span>
            </div>

            {/* Jira issues metrics */}
            <div className="flex items-center justify-between p-3 bg-[#0c0d0f]/40 border border-slate-800 rounded-xl text-xs font-mono">
              <div className="flex items-center gap-2">
                <KanbanSquare className="w-4 h-4 text-amber-500" />
                <span className="font-sans text-slate-300">Sprint Backlog Left</span>
              </div>
              <span className="text-amber-500 font-bold">
                {integrationStats.jira.connected ? integrationStats.jira.inProgressCount + integrationStats.jira.todoCount : "—"}
              </span>
            </div>

            {/* Calendars today */}
            <div className="flex items-center justify-between p-3 bg-[#0c0d0f]/40 border border-slate-800 rounded-xl text-xs font-mono">
              <div className="flex items-center gap-2">
                <CalendarIcon className="w-4 h-4 text-emerald-400" />
                <span className="font-sans text-slate-300">Meeting Overload Today</span>
              </div>
              <span className="text-emerald-400 font-bold">
                {integrationStats.googleCalendar.connected ? `${integrationStats.googleCalendar.meetingsDuration} min` : "—"}
              </span>
            </div>
          </div>
        </div>

        {/* Right Side: Central Focus zone & Analytics charts summary details */}
        <div className="lg:col-span-8 space-y-6">
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Pomodoro Timer widget */}
            <PomodoroTimer userId={profile?.userId || sandboxId} onSessionSave={handleSaveSession} defaultLength={profile?.pomodoroLength} />

            {/* Google Calendar agendas item check */}
            <div id="calendar_agenda_widget" className="bg-[#111216] border border-slate-800 rounded-2xl p-6 shadow-xl text-white flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <CalendarIcon className="w-4 h-4 text-emerald-400" />
                    <h4 className="text-xs uppercase tracking-widest font-mono font-bold text-slate-300">Sync Daily Schedule</h4>
                  </div>
                  <div className="flex items-center gap-2">
                    {calendarEvents.length > 0 && (
                      <button
                        onClick={handleExportCalendarCSV}
                        className="text-[9px] bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 hover:border-slate-600 rounded px-2 py-0.5 font-mono flex items-center gap-1 transition-colors cursor-pointer"
                        title="Export current view to CSV"
                      >
                        <Download className="w-3 h-3 text-emerald-400" />
                        Export CSV
                      </button>
                    )}
                    <span className="text-[9px] bg-emerald-950/40 text-emerald-400 rounded px-1.5 py-0.5 font-mono">Google Calendar</span>
                  </div>
                </div>

                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {calendarEvents.length === 0 ? (
                    <div className="text-xs text-slate-500 font-mono py-4 border border-dashed border-slate-800 rounded-xl text-center">
                      No Google Calendar sessions pulled today. Click "Sync Calendar" on the left panel.
                    </div>
                  ) : (
                    calendarEvents.map((evt, idx) => (
                      <div key={idx} className="bg-[#0c0d0f]/40 border border-slate-800 p-2.5 rounded-xl flex items-start gap-2 text-xs font-sans">
                        <span className={`w-1.5 h-10 rounded ${evt.isMeeting ? "bg-indigo-500" : "bg-emerald-500"}`}></span>
                        <div className="flex-1 min-w-0">
                          <p className="text-slate-200 font-semibold truncate">{evt.summary}</p>
                          <p className="text-[10px] text-slate-500 font-mono mt-0.5">
                            {new Date(evt.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} - {new Date(evt.endTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </p>
                        </div>
                        {evt.isMeeting && (
                          <span className="text-[9px] bg-indigo-950/30 text-indigo-300 border border-indigo-900/30 font-mono mt-0.5 py-0.5 px-1.5 rounded">
                            Sync Link
                          </span>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Informative advice */}
              <div className="pt-4 border-t border-slate-800 flex items-center gap-2 text-[10px] text-slate-500">
                <Info className="w-3.5 h-3.5 shrink-0 text-slate-400" />
                <span>Syncs live with your Google sign-in scopes calendar block.</span>
              </div>
            </div>
          </div>

          {/* Deep Work and session logs tracker */}
          <DeepWorkTracker
            userId={profile?.userId || sandboxId}
            sessions={sessions}
            onSessionSave={handleSaveSession}
            onSessionDelete={handleDeleteSession}
          />

          {/* Real-time Recharts visualizers & fatigue risk analysis */}
          <ErrorBoundary fallbackName="Productivity Analytics Board">
            <ProductivityCharts sessions={sessions} integrationStats={integrationStats} githubLiveStats={gitStats} />
          </ErrorBoundary>

        </div>

      </main>
    </div>
  );
}
