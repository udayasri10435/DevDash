export interface UserProfile {
  userId: string;
  displayName: string;
  email: string;
  githubToken?: string;
  githubUsername?: string;
  jiraToken?: string;
  jiraDomain?: string;
  deepWorkGoal: number; // in hours
  pomodoroLength: number; // in minutes
}

export interface WorkSession {
  sessionId: string;
  userId: string;
  type: "deep_work" | "pomodoro" | "break";
  startTime: string; // ISO String
  endTime?: string; // ISO String
  duration: number; // in seconds
  notes?: string;
  category?: string; // e.g. "Core Engine", "Bug Fixing", "UI Refinement", "Review / PR", "Planning"
}

export interface IntegrationStats {
  github: {
    connected: boolean;
    username: string;
    commitsCount: number;
    openPrsCount: number;
    mergedPrsCount: number;
    prsReviewSpeed: number; // in hours
  };
  jira: {
    connected: boolean;
    domain: string;
    todoCount: number;
    inProgressCount: number;
    doneCount: number;
    sprintVelocity: number;
  };
  googleCalendar: {
    connected: boolean;
    eventsTodayCount: number;
    meetingsDuration: number; // in minutes
  };
}
