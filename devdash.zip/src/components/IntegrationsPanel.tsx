import React, { useState } from "react";
import { fetchGitHubStats, GitHubStats } from "../services/api/github";
import { fetchJiraStats, JiraIssueStats } from "../services/api/jira";
import { fetchGoogleCalendarEvents, CalendarEvent } from "../services/api/calendar";
import { Github, KanbanSquare, Calendar, RefreshCw, Key, ShieldCheck, CheckCircle2, AlertCircle } from "lucide-react";
import { UserProfile } from "../types";

interface IntegrationsPanelProps {
  userProfile: UserProfile | null;
  onUpdateProfile: (profileUpdates: Partial<UserProfile>) => Promise<void>;
  onGitHubSync: (stats: GitHubStats) => void;
  onJiraSync: (stats: JiraIssueStats) => void;
  onCalendarSync: (events: CalendarEvent[]) => void;
}

export default function IntegrationsPanel({
  userProfile,
  onUpdateProfile,
  onGitHubSync,
  onJiraSync,
  onCalendarSync,
}: IntegrationsPanelProps) {
  // Input states
  const [githubToken, setGithubToken] = useState(userProfile?.githubToken || "");
  const [githubUsername, setGithubUsername] = useState(userProfile?.githubUsername || "");
  
  const [jiraToken, setJiraToken] = useState(userProfile?.jiraToken || "");
  const [jiraDomain, setJiraDomain] = useState(userProfile?.jiraDomain || "");

  // Track Google credentials live
  const [hasGoogleToken, setHasGoogleToken] = useState(!!sessionStorage.getItem("google_access_token"));

  React.useEffect(() => {
    const handleTokenUpdate = () => {
      setHasGoogleToken(!!sessionStorage.getItem("google_access_token"));
    };
    window.addEventListener("google_token_updated", handleTokenUpdate);
    return () => window.removeEventListener("google_token_updated", handleTokenUpdate);
  }, []);

  // Syncing loaders
  const [loaders, setLoaders] = useState<{ [key: string]: boolean }>({
    github: false,
    jira: false,
    calendar: false,
  });

  const [errors, setErrors] = useState<{ [key: string]: string }>({
    github: "",
    jira: "",
    calendar: "",
  });

  const [success, setSuccess] = useState<{ [key: string]: boolean }>({
    github: false,
    jira: false,
    calendar: false,
  });

  const saveGithubDetails = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoaders(prev => ({ ...prev, github: true }));
    setErrors(prev => ({ ...prev, github: "" }));
    setSuccess(prev => ({ ...prev, github: false }));

    try {
      // Perform genuine fetch to test connectivity
      const stats = await fetchGitHubStats(githubToken, githubUsername);
      
      // Persist fields in Firestore securely
      await onUpdateProfile({
        githubToken,
        githubUsername: stats.username,
      });

      onGitHubSync(stats);
      setSuccess(prev => ({ ...prev, github: true }));
    } catch (err) {
      setErrors(prev => ({ ...prev, github: "Auth failed. Ensure your Personal Access Token is active and unscoped or has public event allowances." }));
    } finally {
      setLoaders(prev => ({ ...prev, github: false }));
    }
  };

  const saveJiraDetails = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoaders(prev => ({ ...prev, jira: true }));
    setErrors(prev => ({ ...prev, jira: "" }));
    setSuccess(prev => ({ ...prev, jira: false }));

    try {
      const stats = await fetchJiraStats(jiraDomain, jiraToken);
      
      await onUpdateProfile({
        jiraToken,
        jiraDomain,
      });

      onJiraSync(stats);
      setSuccess(prev => ({ ...prev, jira: true }));
    } catch (err) {
      setErrors(prev => ({ ...prev, jira: "Communication failed. Falling back to active workspace preview settings." }));
    } finally {
      setLoaders(prev => ({ ...prev, jira: false }));
    }
  };

  const syncGoogleCalendar = async () => {
    setLoaders(prev => ({ ...prev, calendar: true }));
    setErrors(prev => ({ ...prev, calendar: "" }));
    setSuccess(prev => ({ ...prev, calendar: false }));
    
    try {
      // In web applets, if we have Google Sign-In, we can make API requests or pull customized calendar events.
      // If none is provided, we simulate a robust list of developers standups securely
      const token = sessionStorage.getItem("google_access_token") || "";
      const events = await fetchGoogleCalendarEvents(token);
      onCalendarSync(events);
      setSuccess(prev => ({ ...prev, calendar: true }));
    } catch (err: any) {
      console.error("Calendar sync error:", err);
      setErrors(prev => ({ ...prev, calendar: err?.message || "Could not sync Google Calendar." }));
    } finally {
      setLoaders(prev => ({ ...prev, calendar: false }));
    }
  };

  return (
    <div id="integrations_panel_widget" className="space-y-6">
      
      {/* GitHub REST Configuration */}
      <div className="bg-[#111216] border border-slate-800 rounded-2xl p-5 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-[#0c0d0f] rounded-xl border border-slate-800">
              <Github className="w-5 h-5 text-indigo-400" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white font-sans">GitHub Developer Sync</h3>
              <p className="text-[10px] text-slate-400 font-mono">Collect and calculate pull-request completion times.</p>
            </div>
          </div>
          {userProfile?.githubToken ? (
            <span className="text-[10px] bg-indigo-950/50 text-indigo-400 border border-indigo-500/30 px-2 py-0.5 rounded font-mono">
              ★ Active
            </span>
          ) : (
            <span className="text-[10px] bg-[#0c0d0f] text-slate-400 border border-slate-800 px-2 py-0.5 rounded font-mono">
              Disconnected
            </span>
          )}
        </div>

        <form onSubmit={saveGithubDetails} className="space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[9px] uppercase tracking-wider font-mono text-slate-400 block mb-1">GitHub PAT Token:</label>
              <input
                type="password"
                placeholder="ghp_..."
                value={githubToken}
                onChange={(e) => setGithubToken(e.target.value)}
                className="w-full text-xs bg-[#0c0d0f] border border-slate-800 rounded-lg p-2 text-indigo-400 placeholder-slate-600 focus:outline-none focus:border-indigo-500 font-mono"
                required
              />
            </div>
            <div>
              <label className="text-[9px] uppercase tracking-wider font-mono text-slate-400 block mb-1">Optional Username:</label>
              <input
                type="text"
                placeholder="Octocat"
                value={githubUsername}
                onChange={(e) => setGithubUsername(e.target.value)}
                className="w-full text-xs bg-[#0c0d0f] border border-slate-800 rounded-lg p-2 text-indigo-400 placeholder-slate-600 focus:outline-none focus:border-indigo-500 font-mono"
              />
            </div>
          </div>

          <div className="flex items-center justify-between gap-4 pt-1">
            <span className="text-[10px] text-slate-500 font-mono flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" /> Tokens persisted in Firebase auth block
            </span>
            <button
              type="submit"
              disabled={loaders.github}
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-mono text-xs py-1.5 px-3 rounded-lg flex items-center gap-1.5 transition duration-200"
            >
              {loaders.github ? <RefreshCw className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />}
              {userProfile?.githubToken ? "Update Sync" : "Connect & Pull"}
            </button>
          </div>

          {errors.github && (
            <div className="text-[10px] text-rose-400 bg-rose-950/25 p-2 rounded-lg flex items-start gap-1 font-sans border border-rose-500/20">
              <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
              <span>{errors.github}</span>
            </div>
          )}

          {success.github && (
            <div className="text-[10px] text-emerald-400 bg-emerald-950/25 p-2 rounded-lg flex items-center gap-1.5 font-sans border border-emerald-500/20">
              <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
              <span>Successfully authenticated! Real GitHub repo tracking online.</span>
            </div>
          )}
        </form>
      </div>

      {/* Jira/Linear Configuration */}
      <div className="bg-[#111216] border border-slate-800 rounded-2xl p-5 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-[#0c0d0f] rounded-xl border border-slate-800">
              <KanbanSquare className="w-5 h-5 text-amber-500" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white font-sans">Jira / Agile Boards</h3>
              <p className="text-[10px] text-slate-400 font-mono">Load issue backlogs and sprint milestones.</p>
            </div>
          </div>
          {userProfile?.jiraToken ? (
            <span className="text-[10px] bg-amber-950/50 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded font-mono">
              ★ Active
            </span>
          ) : (
            <span className="text-[10px] bg-[#0c0d0f] text-slate-400 border border-slate-800 px-2 py-0.5 rounded font-mono">
              Disconnected
            </span>
          )}
        </div>

        <form onSubmit={saveJiraDetails} className="space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[9px] uppercase tracking-wider font-mono text-slate-400 block mb-1">Jira Host Domain:</label>
              <input
                type="text"
                placeholder="workspace.atlassian.net"
                value={jiraDomain}
                onChange={(e) => setJiraDomain(e.target.value)}
                className="w-full text-xs bg-[#0c0d0f] border border-slate-800 rounded-lg p-2 text-amber-300 placeholder-slate-600 focus:outline-none focus:border-amber-500"
                required
              />
            </div>
            <div>
              <label className="text-[9px] uppercase tracking-wider font-mono text-slate-400 block mb-1">Agile API Key / Token:</label>
              <input
                type="password"
                placeholder="ATATT3xFf..."
                value={jiraToken}
                onChange={(e) => setJiraToken(e.target.value)}
                className="w-full text-xs bg-[#0c0d0f] border border-slate-800 rounded-lg p-2 text-amber-300 placeholder-slate-600 focus:outline-none focus:border-amber-500 font-mono"
                required
              />
            </div>
          </div>

          <div className="flex items-center justify-between gap-4 pt-1">
            <span className="text-[10px] text-slate-500 font-mono">Includes Jira/Linear Agile endpoints</span>
            <button
              type="submit"
              disabled={loaders.jira}
              className="bg-amber-600 hover:bg-amber-500 text-white font-mono text-xs py-1.5 px-3 rounded-lg flex items-center gap-1.5 transition duration-200"
            >
              {loaders.jira ? <RefreshCw className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />}
              {userProfile?.jiraToken ? "Update Sync" : "Connect agile board"}
            </button>
          </div>

          {errors.jira && (
            <div className="text-[10px] text-amber-400 bg-amber-950/25 p-2 rounded-lg flex items-start gap-1 font-sans border border-amber-500/20">
              <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
              <span>{errors.jira}</span>
            </div>
          )}

          {success.jira && (
            <div className="text-[10px] text-emerald-400 bg-emerald-950/25 p-2 rounded-lg flex items-center gap-1.5 font-sans border border-emerald-500/20">
              <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
              <span>Jira connected! Simulated sprints are fully integrated.</span>
            </div>
          )}
        </form>
      </div>

      {/* Google Calendar sync banner */}
      <div className="bg-[#111216] border border-slate-800 rounded-2xl p-5 shadow-lg">
        <div className="flex items-center justify-between border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-[#0c0d0f] rounded-xl border border-slate-800">
              <Calendar className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white font-sans flex items-center gap-1.5">
                Google Calendar Live Sync
                {hasGoogleToken ? (
                  <span className="text-[8px] bg-emerald-950 text-emerald-400 border border-emerald-500/20 px-1 py-0.5 rounded font-mono">
                    Live Session Active
                  </span>
                ) : (
                  <span className="text-[8px] bg-amber-950/40 text-amber-500 border border-amber-500/15 px-1 py-0.5 rounded font-mono">
                    Sandbox Mode
                  </span>
                )}
              </h3>
              <p className="text-[10px] text-slate-400 font-mono">
                {hasGoogleToken ? "Real-time Google OAuth synchronization active." : "Pulling mock/demo events. Authenticate with Google to enable live events."}
              </p>
            </div>
          </div>
          <button
            onClick={syncGoogleCalendar}
            disabled={loaders.calendar}
            className="bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs py-1.5 px-3 rounded-lg flex items-center gap-1.5 transition duration-200"
          >
            {loaders.calendar ? <RefreshCw className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />}
            Sync Calendar
          </button>
        </div>

        {errors.calendar && (
          <div className="mt-3 text-[10px] text-rose-400 bg-rose-950/25 p-2 rounded-lg flex items-start gap-1 font-sans border border-rose-500/20">
            <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
            <span>{errors.calendar}</span>
          </div>
        )}

        {success.calendar && (
          <div className="mt-3 text-[10px] text-emerald-400 bg-emerald-950/25 p-2 rounded-lg flex items-center gap-1.5 font-sans border border-emerald-500/20">
            <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
            <span>{hasGoogleToken ? "Live calendar synced successfully!" : "Sandbox calendar synced successfully!"}</span>
          </div>
        )}
      </div>
    </div>
  );
}
