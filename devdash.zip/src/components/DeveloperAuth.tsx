import React, { useState } from "react";
import { signInWithPopup, signInWithRedirect, signInWithEmailAndPassword, createUserWithEmailAndPassword, GoogleAuthProvider } from "firebase/auth";
import { auth, googleProvider } from "../firebase";
import { Terminal, Key, Shield, Chrome, Lock, User, ArrowRight, Activity, Cpu, HelpCircle, ExternalLink, ChevronDown, ChevronUp } from "lucide-react";

interface DeveloperAuthProps {
  onSandboxLogin: () => void;
}

export default function DeveloperAuth({ onSandboxLogin }: DeveloperAuthProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isSignUp, setIsSignUp] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [showTroubleshoot, setShowTroubleshoot] = useState(false);

  const handleGoogleLogin = async () => {
    setLoading(true);
    setMessage("");
    try {
      // Configure scopes for calendar events readonly
      googleProvider.addScope("https://www.googleapis.com/auth/calendar.events.readonly");
      const result = await signInWithPopup(auth, googleProvider);
      const credential = GoogleAuthProvider.credentialFromResult(result);
      const token = credential?.accessToken;
      if (token) {
        sessionStorage.setItem("google_access_token", token);
        window.dispatchEvent(new Event("google_token_updated"));
      }
    } catch (err: any) {
      console.warn("Popup blocked or failed inside iframe sandbox container:", err);
      try {
        // Fallback to redirect
        await signInWithRedirect(auth, googleProvider);
      } catch (redirectErr: any) {
        console.error("Google Auth error:", redirectErr);
        setMessage("Google Sign-In returned an authorization error. If you see 'Access blocked (Error 403: access_denied)', please open the Troubleshooting guide below!");
        setShowTroubleshoot(true);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage("");
    try {
      if (isSignUp) {
        await createUserWithEmailAndPassword(auth, email, password);
        setMessage("Account registered successfully! Welcome to DevDash.");
      } else {
        await signInWithEmailAndPassword(auth, email, password);
      }
    } catch (err: any) {
      setMessage(err.message || "Authentication rejected. Try another option or sandbox bypass.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="developer_auth_view" className="min-h-screen bg-[#0c0d0f] flex items-center justify-center px-4 relative overflow-hidden">
      {/* Visual neon matrix lines */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(99,102,241,0.06),transparent_70%)]"></div>
      
      <div className="w-full max-w-md bg-[#111216] border border-slate-800 rounded-3xl p-8 shadow-2xl relative z-10 backdrop-blur-md">
        
        {/* Terminal Header */}
        <div className="flex items-center gap-2.5 mb-8 justify-center">
          <div className="p-2.5 bg-indigo-600/10 border border-indigo-500/20 rounded-2xl">
            <Cpu className="w-6 h-6 text-indigo-400 rotate-12" />
          </div>
          <div>
            <h1 className="text-xl font-black tracking-tight text-white font-sans flex items-center gap-1.5">
              <span>DEVDASH</span>
              <span className="text-xs font-mono py-0.5 px-1.5 bg-indigo-950 text-indigo-400 border border-indigo-500/30 rounded">v1.0</span>
            </h1>
            <p className="text-[10px] text-slate-400 font-mono tracking-widest uppercase">Productivity & Fatigue Matrix</p>
          </div>
        </div>

        {/* Security warning under sandbox limits */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3.5 mb-6 text-xs text-slate-400">
          <div className="flex gap-2">
            <Shield className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
            <p className="leading-relaxed font-sans">
              For fully persistent user timelines, login via Google. If inside a restricted iframe sandbox, select 
              <span className="text-amber-400 font-medium font-mono"> Bypass / Active Sandbox</span> for instant access.
            </p>
          </div>
        </div>

        {/* Traditional auth forms */}
        <form onSubmit={handleEmailAuth} className="space-y-4">
          <div>
            <label className="text-[10px] uppercase tracking-wider font-mono text-slate-400 block mb-1.5">Developer Email:</label>
            <div className="relative">
              <User className="absolute left-3.5 top-3 w-4 h-4 text-slate-500" />
              <input
                type="email"
                placeholder="developer@studio.internal"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full text-xs bg-[#0c0d0f] border border-slate-800 rounded-xl py-3 pl-10 pr-4 text-white focus:outline-none focus:border-indigo-500 transition"
                required
              />
            </div>
          </div>

          <div>
            <label className="text-[10px] uppercase tracking-wider font-mono text-slate-400 block mb-1.5">Workspace Secret:</label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-3 w-4 h-4 text-slate-500" />
              <input
                type="password"
                placeholder="••••••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full text-xs bg-[#0c0d0f] border border-slate-800 rounded-xl py-3 pl-10 pr-4 text-white focus:outline-none focus:border-indigo-500 transition"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-mono text-xs py-3 rounded-xl flex items-center justify-center gap-1.5 transition duration-200"
          >
            {loading ? "Decrypting credentials..." : isSignUp ? "Establish Developer Node" : "Decrypt & Enter Dashboard"}
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="flex justify-between items-center mt-3 text-[11px] font-mono text-slate-400">
          <button
            onClick={() => setIsSignUp(!isSignUp)}
            className="hover:text-indigo-400 transition"
          >
            {isSignUp ? "Already registered? Login" : "First time? Set key"}
          </button>
        </div>

        {/* Separator */}
        <div className="relative flex py-4 items-center">
          <div className="flex-grow border-t border-slate-800"></div>
          <span className="flex-shrink mx-4 text-[10px] font-mono text-slate-500 uppercase">Or alternate protocols</span>
          <div className="flex-grow border-t border-slate-800"></div>
        </div>

        <div className="space-y-3">
          <button
            onClick={handleGoogleLogin}
            disabled={loading}
            className="w-full bg-slate-900 hover:bg-slate-800 border border-slate-800 text-white font-sans text-xs py-2.5 rounded-xl flex items-center justify-center gap-2.5 transition duration-200"
          >
            <Chrome className="w-4 h-4 text-indigo-400" /> Google Developer Auth
          </button>

          <button
            onClick={onSandboxLogin}
            className="w-full bg-amber-950/20 hover:bg-amber-950/40 border border-amber-500/20 text-amber-300 font-mono text-[11px] py-2.5 rounded-xl flex items-center justify-center gap-2 transition duration-200"
          >
            Bypass / Active Sandbox Mode (Offline Test)
          </button>
        </div>

        {/* Dynamic Troubleshooting Expandable Area */}
        <div className="mt-4 border border-slate-800 rounded-xl bg-slate-900/40 overflow-hidden">
          <button
            type="button"
            onClick={() => setShowTroubleshoot(!showTroubleshoot)}
            className="w-full flex items-center justify-between px-4 py-3 text-[11px] font-mono text-slate-400 hover:text-indigo-400 transition"
          >
            <span className="flex items-center gap-2">
              <HelpCircle className="w-3.5 h-3.5 text-indigo-400" />
              Troubleshoot Google Auth (Error 403)
            </span>
            {showTroubleshoot ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>

          {showTroubleshoot && (
            <div className="px-4 pb-4 pt-1 border-t border-slate-800 text-[11px] text-slate-300 font-sans space-y-3">
              <p className="text-[10px] text-amber-400/90 font-mono leading-relaxed">
                Google blocks unverified external apps unless your Google email is added as an approved test user.
              </p>
              
              <div className="space-y-2.5">
                <div className="flex gap-2">
                  <span className="flex items-center justify-center w-4 h-4 rounded bg-indigo-600/20 text-indigo-400 border border-indigo-500/35 text-[9px] font-bold shrink-0 mt-0.5">1</span>
                  <p>
                    Go to the <a href="https://console.cloud.google.com" target="_blank" rel="noopener noreferrer" className="text-indigo-400 underline inline-flex items-center gap-0.5 hover:text-indigo-300">Google Cloud Console <ExternalLink className="w-2.5 h-2.5" /></a>.
                  </p>
                </div>
                
                <div className="flex gap-2">
                  <span className="flex items-center justify-center w-4 h-4 rounded bg-indigo-600/20 text-indigo-400 border border-indigo-500/35 text-[9px] font-bold shrink-0 mt-0.5">2</span>
                  <p>
                    Ensure your active GCP project is selected in the top bar: <code className="bg-slate-950 px-1 py-0.5 rounded text-indigo-300 font-mono text-[10px]">totemic-router-tdpgw</code>
                  </p>
                </div>

                <div className="flex gap-2">
                  <span className="flex items-center justify-center w-4 h-4 rounded bg-indigo-600/20 text-indigo-400 border border-indigo-500/35 text-[9px] font-bold shrink-0 mt-0.5">3</span>
                  <p>
                    In the left navigation menu, go to <span className="font-semibold text-white">APIs & Services</span> &gt; <span className="font-semibold text-white">OAuth consent screen</span>.
                  </p>
                </div>

                <div className="flex gap-2">
                  <span className="flex items-center justify-center w-4 h-4 rounded bg-indigo-600/20 text-indigo-400 border border-indigo-500/35 text-[9px] font-bold shrink-0 mt-0.5">4</span>
                  <p>
                    Scroll down to the <span className="font-semibold text-white">Test users</span> block, click <span className="text-indigo-400 font-semibold">+ ADD USERS</span>.
                  </p>
                </div>

                <div className="flex gap-2">
                  <span className="flex items-center justify-center w-4 h-4 rounded bg-indigo-600/20 text-indigo-400 border border-indigo-500/35 text-[9px] font-bold shrink-0 mt-0.5">5</span>
                  <p>
                    Enter your email addresses (e.g. <code className="bg-slate-950 px-1 text-[10px] text-amber-300 font-mono">udayatube2020@gmail.com</code> and <code className="bg-slate-950 px-1 text-[10px] text-amber-300 font-mono">udayasrimadushan@gmail.com</code>), click <span className="text-white font-semibold">Save</span>, and try Google Auth again!
                  </p>
                </div>
              </div>

              <div className="mt-2.5 pt-2 border-t border-slate-800 text-[10px] font-mono text-slate-400">
                💡 <span className="text-slate-300">Alternate choice:</span> You can also use the Sandbox Bypass button or register an email node to test right now!
              </div>
            </div>
          )}
        </div>

        {message && (
          <div className="mt-4 text-[10px] text-center font-mono text-amber-400 p-2 border border-amber-950 rounded-lg bg-amber-950/20">
            {message}
          </div>
        )}

      </div>
    </div>
  );
}
