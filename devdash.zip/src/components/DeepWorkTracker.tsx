import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Play, Square, Award, Calendar, Trash2, Clock, CheckCircle, Tag, Plus, MessageSquare } from "lucide-react";
import { WorkSession } from "../types";

interface DeepWorkTrackerProps {
  userId: string;
  sessions: WorkSession[];
  onSessionSave: (session: Omit<WorkSession, "sessionId" | "userId" | "startTime">) => void;
  onSessionDelete?: (sessionId: string) => void;
}

export default function DeepWorkTracker({ userId, sessions, onSessionSave, onSessionDelete }: DeepWorkTrackerProps) {
  // Session creation manual form modal
  const [showManualForm, setShowManualForm] = useState(false);
  const [manualMinutes, setManualMinutes] = useState(45);
  const [manualCategory, setManualCategory] = useState("Code Editing");
  const [manualNotes, setManualNotes] = useState("");

  // Live deep-work chronometer
  const [isChronometerRunning, setIsChronometerRunning] = useState(false);
  const [secondsElapsed, setSecondsElapsed] = useState(0);
  const [choronometerStartTime, setChronometerStartTime] = useState<string | null>(null);

  useEffect(() => {
    let watchId: any = null;
    if (isChronometerRunning) {
      watchId = setInterval(() => {
        setSecondsElapsed((prev) => prev + 1);
      }, 1000);
    }
    return () => {
      if (watchId) clearInterval(watchId);
    };
  }, [isChronometerRunning]);

  const handleStartChronometer = () => {
    setIsChronometerRunning(true);
    setChronometerStartTime(new Date().toISOString());
    setSecondsElapsed(0);
  };

  const handleStopChronometer = () => {
    setIsChronometerRunning(false);
    if (secondsElapsed >= 5) {
      onSessionSave({
        type: "deep_work",
        duration: secondsElapsed,
        category: manualCategory,
        notes: manualNotes || "Live-tracked deep work chronometer flow",
      });
      setManualNotes("");
    } else {
      setIsChronometerRunning(false);
      setSecondsElapsed(0);
      setChronometerStartTime(null);
    }
    setSecondsElapsed(0);
    setChronometerStartTime(null);
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSessionSave({
      type: "deep_work",
      duration: manualMinutes * 60,
      category: manualCategory,
      notes: manualNotes || "Manual back-logged deep work focus run",
    });
    setManualNotes("");
    setShowManualForm(false);
  };

  const formatChronometer = (totalSecs: number) => {
    const hours = Math.floor(totalSecs / 3600);
    const minutes = Math.floor((totalSecs % 3600) / 60);
    const secs = totalSecs % 60;
    return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  // Compute stats on sessions
  const deepWorkSessions = sessions.filter((s) => s.type === "deep_work" || s.type === "pomodoro");
  const totalMinutesToday = deepWorkSessions.reduce((acc, s) => {
    // only count sessions from today
    const sessionDate = new Date(s.startTime).toDateString();
    const todayDate = new Date().toDateString();
    if (sessionDate === todayDate) {
      return acc + s.duration / 60;
    }
    return acc;
  }, 0);

  // Computing actual streak days based on sessions history
  const computeStreak = (history: WorkSession[]): number => {
    if (history.length === 0) return 0;
    const uniqueDates = Array.from(
      new Set(history.map((s) => new Date(s.startTime).toDateString()))
    ).map((d) => new Date(d));

    // Sort descending
    uniqueDates.sort((a, b) => b.getTime() - a.getTime());

    let currentStreak = 0;
    let expectedDate = new Date();
    expectedDate.setHours(0, 0, 0, 0);

    for (const uDate of uniqueDates) {
      uDate.setHours(0, 0, 0, 0);
      const diffTime = expectedDate.getTime() - uDate.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

      if (diffDays === 0 || diffDays === 1) {
        currentStreak++;
        expectedDate = uDate;
      } else {
        break;
      }
    }
    return currentStreak;
  };

  const currentStreak = computeStreak(sessions);

  return (
    <div id="deep_work_tracker_widget" className="bg-[#111216] border border-slate-800 rounded-2xl p-6 shadow-xl text-white">
      {/* Real-time stats widgets */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-[#0c0d0f]/60 border border-slate-800/80 rounded-xl p-4 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-400 font-mono block uppercase tracking-wider">Today's Focus</span>
            <span className="text-2xl font-extrabold text-indigo-400 font-mono">{Math.round(totalMinutesToday)}m</span>
          </div>
          <div className="bg-[#0c0d0f]/40 p-2.5 border border-slate-800 rounded-lg">
            <Clock className="w-5 h-5 text-indigo-400" />
          </div>
        </div>
        <div className="bg-[#0c0d0f]/60 border border-slate-800/80 rounded-xl p-4 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-400 font-mono block uppercase tracking-wider">Active Streak</span>
            <span className="text-2xl font-extrabold text-amber-500 font-mono">{currentStreak} Days</span>
          </div>
          <div className="bg-amber-950/40 p-2.5 border border-amber-900/10 rounded-lg">
            <Award className="w-5 h-5 text-amber-500 animate-pulse" />
          </div>
        </div>
      </div>

      {/* Chronometer & Quick Flow Control */}
      <div className="bg-[#0c0d0f]/45 border border-slate-800 rounded-xl p-5 mb-6">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs uppercase font-mono tracking-widest text-slate-300">
            {isChronometerRunning ? "Deep Work State Active" : "Ready For Focus"}
          </span>
          {isChronometerRunning && (
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
            </span>
          )}
        </div>

        <div className="flex items-center justify-between">
          <div>
            {isChronometerRunning ? (
              <span className="text-3xl font-bold font-mono tracking-wider text-rose-400 animate-pulse">
                {formatChronometer(secondsElapsed)}
              </span>
            ) : (
              <span className="text-slate-400 text-sm">Initiate an open focus session.</span>
            )}
          </div>

          <div className="flex gap-2">
            {isChronometerRunning ? (
              <button
                onClick={handleStopChronometer}
                className="bg-rose-600 hover:bg-rose-500 text-white p-2.5 px-4 rounded-xl flex items-center gap-2 transition duration-200 text-xs font-medium font-mono"
              >
                <Square className="w-4 h-4 fill-white" /> Stop & Log
              </button>
            ) : (
              <div className="flex gap-2 w-full">
                <button
                  onClick={handleStartChronometer}
                  className="bg-indigo-600/30 hover:bg-indigo-600 border border-indigo-500/50 hover:text-white text-indigo-300 p-2.5 px-4 rounded-xl flex items-center gap-2 transition duration-200 text-xs font-medium font-mono"
                >
                  <Play className="w-4 h-4 fill-indigo-300" /> Start deep work timer
                </button>
                <button
                  onClick={() => setShowManualForm(!showManualForm)}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-300 p-2.5 rounded-xl transition duration-200"
                  title="Log session manually"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Input notes pre-logging */}
        {isChronometerRunning && (
          <div className="mt-4 pt-4 border-t border-slate-800 space-y-3">
            <div>
              <label className="text-[10px] text-slate-400 uppercase font-mono tracking-wider block mb-1">Ongoing Notes:</label>
              <input
                type="text"
                placeholder="What objective are you coding..."
                value={manualNotes}
                onChange={(e) => setManualNotes(e.target.value)}
                className="w-full text-xs bg-slate-900 border border-slate-800 rounded-lg py-2 px-3 focus:outline-none focus:ring-1 focus:ring-rose-500 text-slate-300"
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-400 uppercase font-mono tracking-wider block mb-1">Context Category:</label>
              <div className="flex gap-1.5 flex-wrap">
                {["Code Editing", "UI Refinement", "Review / PR", "Planning"].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setManualCategory(cat)}
                    className={`py-1 px-2.5 rounded text-[10px] uppercase font-mono transition duration-150 border ${manualCategory === cat ? "bg-rose-950/40 border-rose-500/50 text-rose-300" : "bg-slate-800/40 border-slate-800 text-slate-400 hover:bg-slate-800"}`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Manual session creation modal overlay */}
      <AnimatePresence>
        {showManualForm && (
          <motion.form
            onSubmit={handleManualSubmit}
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-[#0c0d0f]/80 border border-slate-800/70 rounded-xl p-4 mb-6 space-y-4 overflow-hidden"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs font-bold font-mono text-slate-300 uppercase tracking-wider">Log Manual Accomplishment</span>
              <button
                type="button"
                onClick={() => setShowManualForm(false)}
                className="text-slate-500 hover:text-slate-300 text-xs"
              >
                ✕ Close
              </button>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] text-slate-400 uppercase font-mono tracking-wider block mb-1">Focus Duration (Minutes):</label>
                <input
                  type="number"
                  min="1"
                  max="480"
                  value={manualMinutes}
                  onChange={(e) => setManualMinutes(parseInt(e.target.value) || 25)}
                  className="w-full text-xs bg-slate-900 border border-slate-800 rounded-lg p-2 text-white focus:outline-none focus:border-indigo-500"
                  required
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400 uppercase font-mono tracking-wider block mb-1">Target Category:</label>
                <select
                  value={manualCategory}
                  onChange={(e) => setManualCategory(e.target.value)}
                  className="w-full text-xs bg-slate-900 border border-slate-800 rounded-lg p-2 text-white focus:outline-none"
                >
                  <option>Code Editing</option>
                  <option>UI Refinement</option>
                  <option>Review / PR</option>
                  <option>Planning</option>
                  <option>Wellness Stretch</option>
                </select>
              </div>
            </div>

            <div>
              <label className="text-[10px] text-slate-400 uppercase font-mono tracking-wider block mb-1">Commit/Accomplishment Log:</label>
              <textarea
                placeholder="Brief description of work done..."
                value={manualNotes}
                onChange={(e) => setManualNotes(e.target.value)}
                className="w-full text-xs bg-slate-900 border border-slate-800 rounded-lg p-2 h-16 text-white focus:outline-none"
              ></textarea>
            </div>

            <button
              type="submit"
              className="w-full bg-indigo-600 hover:bg-indigo-500 py-2 rounded-xl text-xs font-semibold font-mono"
            >
              Add Focus Block Entry
            </button>
          </motion.form>
        )}
      </AnimatePresence>

      {/* Historical logs table list representation */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xs uppercase tracking-widest font-mono font-bold text-slate-400">Chronological Logs ({sessions.length})</h3>
          <span className="text-[10px] text-slate-500 font-mono">Durable Cloud Sync Active</span>
        </div>

        <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
          {sessions.length === 0 ? (
            <div className="text-center py-6 text-slate-500 text-xs font-mono border border-dashed border-slate-800/80 rounded-xl">
              No sessions compiled yet. Trigger a pomodoro or chronometer sprint.
            </div>
          ) : (
            sessions.map((sess) => (
              <div
                key={sess.sessionId}
                className="bg-[#0c0d0f]/50 border border-slate-800 rounded-xl p-3 flex justify-between items-start gap-4 hover:border-slate-700 transition"
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className={`text-[9px] uppercase font-mono px-1.5 py-0.5 rounded ${sess.type === "deep_work" ? "bg-rose-950/40 text-rose-300 border border-rose-500/20" : sess.type === "pomodoro" ? "bg-indigo-950/40 text-indigo-300 border border-indigo-500/20" : "bg-emerald-950/40 text-emerald-300 border border-emerald-500/20"}`}>
                      {sess.type.replace("_", " ")}
                    </span>
                    <span className="text-[10px] text-slate-400 flex items-center font-mono gap-1">
                      <Tag className="w-2.5 h-2.5" />
                      {sess.category || "General Work"}
                    </span>
                    <span className="text-[9px] text-slate-500 font-mono ml-auto">
                      {new Date(sess.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-xs text-slate-200 mt-1.5 font-sans truncate">{sess.notes || "No notes registered"}</p>
                  <p className="text-[10px] text-slate-500 font-mono flex items-center gap-1 mt-1">
                    <Clock className="w-2.5 h-2.5" /> Checked: {Math.round(sess.duration / 60)}m ({sess.duration}s)
                  </p>
                </div>
                {onSessionDelete && (
                  <button
                    onClick={() => onSessionDelete(sess.sessionId)}
                    className="text-slate-500 hover:text-rose-400 p-1 rounded hover:bg-rose-950/20 transition self-center"
                    title="Delete entry"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
