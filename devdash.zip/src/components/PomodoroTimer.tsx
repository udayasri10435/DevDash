import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Play, Pause, RotateCcw, Flame, Coffee, HelpCircle, Eye, RefreshCw, Compass } from "lucide-react";
import { WorkSession } from "../types";

interface PomodoroTimerProps {
  userId: string;
  onSessionSave: (session: Omit<WorkSession, "sessionId" | "userId" | "startTime">) => void;
  defaultLength?: number;
}

interface BreakSuggestion {
  title: string;
  metric: string;
  description: string;
  icon: React.ReactNode;
}

export default function PomodoroTimer({ userId, onSessionSave, defaultLength = 25 }: PomodoroTimerProps) {
  const [sessionLength, setSessionLength] = useState(defaultLength); // minutes
  const [timeLeft, setTimeLeft] = useState(defaultLength * 60); // seconds
  const [isRunning, setIsRunning] = useState(false);
  const [mode, setMode] = useState<"work" | "break">("work");
  const [notes, setNotes] = useState("");
  const [category, setCategory] = useState("Code Editing");

  // Break suggestion engine
  const [currentBreakIndex, setCurrentBreakIndex] = useState(0);
  const breakSuggestions: BreakSuggestion[] = [
    {
      title: "The 20-20-20 Rule",
      metric: "Mitigates Digital Eye Strain",
      description: "Focus on an object at least 20 feet away for exactly 20 seconds to rest your optic nerve.",
      icon: <Eye className="w-5 h-5 text-indigo-400" />,
    },
    {
      title: "Carpal Tunnel Wrist Flow",
      metric: "Prevents RSIs",
      description: "Extend your hands outward, make 10 slow circular wrist rotations to unload tension.",
      icon: <RefreshCw className="w-5 h-5 text-emerald-400" />,
    },
    {
      title: "Active Hydration Break",
      metric: "Spikes Cogitive Focus",
      description: "Rise from your seat, traverse to the water station, and slowly drink one full glass of pure water.",
      icon: <Flame className="w-5 h-5 text-cyan-400" />,
    },
    {
      title: "Inhale/Exhale Sine Stretch",
      metric: "Oxygenates Brain Tissue",
      description: "Bring hands to ceiling, inhale for 4s, hold for 4s, and exhale for 4s. Feel the chest relax.",
      icon: <Compass className="w-5 h-5 text-amber-500" />,
    },
  ];

  // Sync timeLeft when defaultLength changes
  useEffect(() => {
    setTimeLeft(sessionLength * 60);
  }, [sessionLength]);

  // Keep countdown running when active
  useEffect(() => {
    let timerId: any = null;
    if (isRunning) {
      timerId = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (timerId) clearInterval(timerId);
    };
  }, [isRunning]);

  // Handle timer completion in a separate effect when timeLeft hits 0
  useEffect(() => {
    if (timeLeft === 0 && isRunning) {
      setIsRunning(false);
      handleTimerComplete();
    }
  }, [timeLeft, isRunning]);

  const handleTimerComplete = () => {
    // Save to Firestore through callbacks
    if (mode === "work") {
      onSessionSave({
        type: "pomodoro",
        duration: sessionLength * 60,
        notes: notes || "Pomodoro focused terminal sprint",
        category,
      });
      // Switch mode
      setMode("break");
      setTimeLeft(5 * 60); // 5 min break
      // Rotate break suggestion
      setCurrentBreakIndex((prev) => (prev + 1) % breakSuggestions.length);
      setNotes("");
    } else {
      onSessionSave({
        type: "break",
        duration: 5 * 60,
        notes: "Rest and physical recharge",
        category: "Recreation",
      });
      setMode("work");
      setTimeLeft(sessionLength * 60);
    }

    // Play visual highlight / synthesize beep
    triggerAudioBeep();
  };

  const triggerAudioBeep = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();
      osc.connect(gainNode);
      gainNode.connect(audioCtx.destination);
      osc.type = "sine";
      osc.frequency.setValueAtTime(880, audioCtx.currentTime); // A5 note
      gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.3);
    } catch (e) {
      console.log("Audio not authorized or blocked by browser sandboxing framework.");
    }
  };

  const toggleTimer = () => {
    setIsRunning(!isRunning);
  };

  const resetTimer = () => {
    setIsRunning(false);
    setTimeLeft((mode === "work" ? sessionLength : 5) * 60);
  };

  const skipTimer = () => {
    handleTimerComplete();
  };

  const formatTime = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  // Circular progress stroke calculation
  const totalDuration = (mode === "work" ? sessionLength : 5) * 60;
  const progressPercent = ((totalDuration - timeLeft) / totalDuration) * 100;
  const strokeDashoffset = 280 - (280 * progressPercent) / 100;

  return (
    <div id="pomodoro_timer_widget" className="bg-[#111216] border border-slate-800 rounded-2xl p-6 shadow-xl text-white relative overflow-hidden">
      {/* Decorative radar pulses */}
      <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/5 rounded-full filter blur-xl"></div>
      
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          {mode === "work" ? (
            <span className="flex h-3.5 w-3.5 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-indigo-500"></span>
            </span>
          ) : (
            <span className="flex h-3.5 w-3.5 relative">
              <span className="animate-pulse absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-60"></span>
              <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500"></span>
            </span>
          )}
          <h2 className="text-base font-bold uppercase tracking-widest text-slate-300">
            {mode === "work" ? "Deep Work Pulse" : "Wellness Break"}
          </h2>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => { setMode("work"); setTimeLeft(sessionLength * 60); setIsRunning(false); }}
            className={`px-3 py-1 rounded text-xs transition duration-200 ${mode === "work" ? "bg-indigo-600/30 text-indigo-400 border border-indigo-500/50" : "bg-slate-800 text-slate-400 hover:text-slate-200"}`}
          >
            Sprint
          </button>
          <button
            onClick={() => { setMode("break"); setTimeLeft(5 * 60); setIsRunning(false); }}
            className={`px-3 py-1 rounded text-xs transition duration-200 ${mode === "break" ? "bg-emerald-600/30 text-emerald-400 border border-emerald-500/50" : "bg-slate-800 text-slate-400 hover:text-slate-200"}`}
          >
            Recharge
          </button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row items-center gap-8 py-4 justify-center md:justify-around">
        {/* Render circular timer SVGs */}
        <div className="relative flex items-center justify-center">
          <svg className="w-44 h-44 -rotate-90">
            <circle
              cx="88"
              cy="88"
              r="76"
              className="stroke-slate-800 fill-none"
              strokeWidth="6"
            />
            {/* Dynamic visual path */}
            <motion.circle
              cx="88"
              cy="88"
              r="76"
              className={`fill-none transition-all duration-300 ${mode === "work" ? "stroke-indigo-500 shadow-indigo-500/55" : "stroke-emerald-500"}`}
              strokeWidth="8"
              strokeDasharray="477.5"
              strokeDashoffset={477.5 * (1 - progressPercent / 100)}
              strokeLinecap="round"
            />
          </svg>
          <div className="absolute flex flex-col items-center">
            <span className="text-4xl font-extrabold font-mono tracking-tight text-white select-none">
              {formatTime(timeLeft)}
            </span>
            <span className="text-xs text-slate-400 mt-1 uppercase tracking-widest font-mono">
              {isRunning ? "FOCUSING" : "STANDBY"}
            </span>
          </div>
        </div>

        {/* Timer Control panel */}
        <div className="flex-1 flex flex-col justify-center space-y-4 w-full max-w-xs">
          <div>
            <label className="text-xs text-slate-400 font-mono flex items-center justify-between mb-1">
              <span>Sprint Duration:</span>
              <span className="text-indigo-400 font-bold">{sessionLength} min</span>
            </label>
            <input
              type="range"
              min="5"
              max="60"
              step="5"
              disabled={isRunning}
              value={sessionLength}
              onChange={(e) => setSessionLength(parseInt(e.target.value))}
              className="w-full bg-slate-800 h-1.5 rounded-lg appearance-none cursor-pointer accent-indigo-500 disabled:opacity-40"
            />
          </div>

          <div className="flex justify-between items-center gap-2">
            <button
              onClick={toggleTimer}
              className={`flex-1 flex items-center justify-center gap-2 py-2 px-4 rounded-xl font-medium transition duration-200 shadow-lg ${isRunning ? "bg-amber-600 hover:bg-amber-700 text-white" : "bg-indigo-600 hover:bg-indigo-500 text-white"}`}
            >
              {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              {isRunning ? "Pause" : "Initiate"}
            </button>
            <button
              onClick={resetTimer}
              className="p-2.5 bg-slate-800 hover:bg-slate-700 hover:text-slate-200 text-slate-400 rounded-xl transition duration-200"
              title="Reset Session timer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            {isRunning && (
              <button
                onClick={skipTimer}
                className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 rounded-xl transition duration-200"
                title="Skip to Complete"
              >
                Skip
              </button>
            )}
          </div>

          {/* Activity Category Selection */}
          {mode === "work" && (
            <div className="space-y-1">
              <label className="text-[11px] text-slate-400 font-mono uppercase tracking-wider block">Current Sprint Category:</label>
              <div className="grid grid-cols-2 gap-1.5 text-xs text-slate-300">
                {["Code Editing", "UI Refinement", "Review / PR", "Planning"].map((cat) => (
                  <button
                    key={cat}
                    disabled={isRunning}
                    onClick={() => setCategory(cat)}
                    className={`py-1 px-2 rounded-lg text-left transition duration-150 border disabled:opacity-70 ${category === cat ? "bg-indigo-950/40 border-indigo-500/50 text-indigo-300" : "bg-slate-800/40 border-slate-800 hover:bg-slate-800"}`}
                  >
                    ● {cat}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {mode === "work" && (
        <div className="mt-4 border-t border-slate-800 pt-4">
          <input
            type="text"
            placeholder="Add brief task accomplishment notes..."
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className="w-full text-xs font-sans bg-slate-900 border border-slate-800 focus:border-indigo-500 rounded-lg py-2 px-3 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-slate-300 placeholder-slate-500 transition duration-150"
          />
        </div>
      )}

      {/* Wellness & Micro break advice box */}
      <AnimatePresence mode="wait">
        {mode === "break" && (
          <motion.div
            key="break-box"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="mt-4 border-t border-emerald-950/60 pt-4"
          >
            <div className="bg-emerald-950/20 border border-emerald-800/20 rounded-xl p-3.5">
              <div className="flex items-center gap-2 mb-1.5">
                {breakSuggestions[currentBreakIndex].icon}
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-widest font-mono">
                  {breakSuggestions[currentBreakIndex].title}
                </span>
                <span className="ml-auto text-[10px] bg-emerald-950/50 text-emerald-300 px-2 py-0.5 rounded border border-emerald-900/30">
                  {breakSuggestions[currentBreakIndex].metric}
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed font-sans">
                {breakSuggestions[currentBreakIndex].description}
              </p>
              <button
                onClick={() => setCurrentBreakIndex((prev) => (prev + 1) % breakSuggestions.length)}
                className="mt-2 text-[10px] text-emerald-400 flex items-center gap-1 font-mono uppercase tracking-wider hover:text-emerald-300 transition"
              >
                <Coffee className="w-3 h-3 animate-bounce" /> Get Alternative Suggestion
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
