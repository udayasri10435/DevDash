import React, { ErrorInfo, ReactNode } from "react";
import { ShieldAlert, RefreshCw } from "lucide-react";

interface Props {
  children: ReactNode;
  fallbackName?: string;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export default class ErrorBoundary extends React.Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("ErrorBoundary caught an exception:", error, errorInfo);
  }

  private handleReset = () => {
    this.setState({ hasError: false, error: null });
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="bg-[#111216] border border-rose-500/20 rounded-2xl p-6 text-white space-y-4">
          <div className="flex items-center gap-2 text-rose-400">
            <ShieldAlert className="w-5 h-5 shrink-0" />
            <h3 className="font-bold text-sm">Telemetry Rendering Interrupted</h3>
          </div>
          <p className="text-xs text-slate-400 font-sans leading-relaxed">
            An unexpected error occurred while rendering the {this.props.fallbackName || "component"}. 
            This can happen inside sandboxed iframes due to ResizeObserver constraints or restricted layout nodes.
          </p>
          {this.state.error && (
            <pre className="text-[10px] font-mono bg-slate-950/60 p-3 rounded-lg border border-slate-800 text-rose-300 overflow-x-auto max-h-24">
              {this.state.error.toString()}
            </pre>
          )}
          <button
            onClick={this.handleReset}
            className="flex items-center gap-2 bg-rose-950/40 hover:bg-rose-900/40 border border-rose-500/30 text-rose-300 text-xs font-mono px-3 py-1.5 rounded-lg transition duration-150"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Reset Render Node</span>
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
